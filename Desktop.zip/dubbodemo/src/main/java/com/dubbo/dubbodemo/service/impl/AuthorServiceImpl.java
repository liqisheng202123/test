package com.dubbo.dubbodemo.service.impl;

import com.dubbo.dubbodemo.dao.AuthorDao;
import com.dubbo.dubbodemo.entity.Author;
import com.dubbo.dubbodemo.service.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;



//@ComponentScan(basePackages={"com.dubbo.dubbodemo.*"})
//@Transactional
@com.alibaba.dubbo.config.annotation.Service
public class AuthorServiceImpl implements AuthorService{
    @Autowired
    private AuthorDao authorDao ;

    @Override
    public int addAuthor(Author author) {
        return authorDao.addAuthor(author);
    }

    @Override
    public int updateAuthor(Author author) {
        return authorDao.updateAuthor(author);
    }

    @Override
    public int deleteAuthor(Long id) {
        return authorDao.deleteAuthor(id);
    }

    @Override
    public Author findAuthor(Long id) {
        return authorDao.findAuthor(id);
    }

    @Override
    public List<Author> findAuthorList() {
        return authorDao.findAuthorList();
    }
}
