package com.demo.mq.util;

public class QueueList {
	/**
	 * 业务1队列
	 */
	public static final String BUSINESS1 = "activemq.queue";
	/**
	 * 业务2队列
	 */
	public static final String BUSINESS2 = "activemq.queue2";

}
