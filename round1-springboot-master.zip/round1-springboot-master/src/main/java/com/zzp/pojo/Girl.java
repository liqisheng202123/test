package com.zzp.pojo;

/**
 * Created by zhuzhengping on 2017/4/16.
 * 当配置文件中的属性为二级，用实体类来接受参数
 */
public class Girl {

    private String name;

    private String age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }
}
