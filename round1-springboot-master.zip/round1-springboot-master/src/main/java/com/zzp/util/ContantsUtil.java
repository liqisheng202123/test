package com.zzp.util;

/**
 * Created by zhuzhengping on 2017/5/21.
 */
public class ContantsUtil {

    private final static String ___API_TITLE = "项目API文档";


    public static String API_TITLE = ___API_TITLE;
}
